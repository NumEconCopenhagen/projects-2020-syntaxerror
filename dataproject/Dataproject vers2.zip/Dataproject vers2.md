```python
import os
import numpy as np
import pandas as pd
from datetime import datetime

import seaborn as sns
import matplotlib.pyplot as plt

from matplotlib import pyplot
from matplotlib import dates

import matplotlib.dates as mdates
import matplotlib.ticker as plticker
from matplotlib.dates import DateFormatter
import time



cw = pd.read_csv('ged191.csv')

#Drop unwanted columns 

drop_these = ['id','low', 'high', 'event_clarity', 'date_prec', 'conflict_new_id', 
              'conflict_name','dyad_name', 'dyad_new_id','side_a_new_id','adm_1','adm_2', 'gwnoa', 'side_b_new_id', 'dyad_new_id', 'gwnob', 'number_of_sources'
              , 'source_headline', 'priogrid_gid', 'source_date', 'source_office', 'source_article', 
              'source_original', 'deaths_a', 'deaths_b', 'deaths_civilians', 'deaths_unknown', 'date_start', 
              'date_end', 'country_id', 'side_a', 'side_b', 'where_prec', 'type_of_violence', 'active_year']


cw.drop(drop_these, axis=1, inplace=True) # axis = 1 -> columns, inplace=True -> changed, no copy made


cw_year = cw[cw.year == 2018]


```


```python
# I create dummy variables for regions:
region_dummy = pd.get_dummies(cw_year['region'])
# I merge the two dataframes:
cw_year = pd.concat([cw_year, region_dummy], axis=1)
cw_year.head()

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>year</th>
      <th>where_coordinates</th>
      <th>latitude</th>
      <th>longitude</th>
      <th>geom_wkt</th>
      <th>country</th>
      <th>region</th>
      <th>best</th>
      <th>Africa</th>
      <th>Americas</th>
      <th>Asia</th>
      <th>Europe</th>
      <th>Middle East</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2010</th>
      <td>2018</td>
      <td>Qush Tepa district</td>
      <td>36.193552</td>
      <td>65.352724</td>
      <td>POINT (65.352724 36.193552)</td>
      <td>Afghanistan</td>
      <td>Asia</td>
      <td>45</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2011</th>
      <td>2018</td>
      <td>Imam Sahib district</td>
      <td>37.105713</td>
      <td>68.851658</td>
      <td>POINT (68.851658 37.105713)</td>
      <td>Afghanistan</td>
      <td>Asia</td>
      <td>28</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2012</th>
      <td>2018</td>
      <td>Bala Bagh village</td>
      <td>34.389900</td>
      <td>70.227900</td>
      <td>POINT (70.227900 34.389900)</td>
      <td>Afghanistan</td>
      <td>Asia</td>
      <td>7</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2013</th>
      <td>2018</td>
      <td>Khaki Safed district</td>
      <td>32.755167</td>
      <td>62.073124</td>
      <td>POINT (62.073124 32.755167)</td>
      <td>Afghanistan</td>
      <td>Asia</td>
      <td>23</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2014</th>
      <td>2018</td>
      <td>Khwaja Sabz Posh district</td>
      <td>36.055429</td>
      <td>64.978235</td>
      <td>POINT (64.978235 36.055429)</td>
      <td>Afghanistan</td>
      <td>Asia</td>
      <td>16</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python

cw_year['region'].value_counts()

Asia = cw_year['region'].value_counts().plot(kind='barh')


```


![png](output_2_0.png)



```python
cw_year['country'].value_counts().plot()
```




    <matplotlib.axes._subplots.AxesSubplot at 0x1a279ada50>




![png](output_3_1.png)



```python
#Making the geografical map

import geopandas as gpd
shapefile = 'Overvægtige/DATA/countries_110m/ne_110m_admin_0_countries.shp'
#Read shapefile using Geopandas
gdf = gpd.read_file(shapefile)[['ADMIN', 'ADM0_A3', 'geometry']]
#Rename columns.
gdf.columns = ['country', 'country_code', 'geometry']
gdf.head()

print(gdf[gdf['country'] == 'Antarctica'])
#Drop row corresponding to 'Antarctica'
gdf = gdf.drop(gdf.index[159])

import json
#Read data to json.
cw_year_grouped_json = json.loads(cw_year_grouped.to_json())
#Convert to String like object.
json_data = json.dumps(cw_year_grouped_json)

```


    ---------------------------------------------------------------------------

    CPLE_OpenFailedError                      Traceback (most recent call last)

    fiona/_shim.pyx in fiona._shim.gdal_open_vector()


    fiona/_err.pyx in fiona._err.exc_wrap_pointer()


    CPLE_OpenFailedError: Overvægtige/DATA/countries_110m/ne_110m_admin_0_countries.shp: No such file or directory

    
    During handling of the above exception, another exception occurred:


    DriverError                               Traceback (most recent call last)

    <ipython-input-9-1d2d3cb410f6> in <module>
          4 shapefile = 'Overvægtige/DATA/countries_110m/ne_110m_admin_0_countries.shp'
          5 #Read shapefile using Geopandas
    ----> 6 gdf = gpd.read_file(shapefile)[['ADMIN', 'ADM0_A3', 'geometry']]
          7 #Rename columns.
          8 gdf.columns = ['country', 'country_code', 'geometry']


    ~/.conda/envs/kris/lib/python3.7/site-packages/geopandas/io/file.py in read_file(filename, bbox, **kwargs)
         74 
         75     with fiona_env():
    ---> 76         with reader(path_or_bytes, **kwargs) as features:
         77 
         78             # In a future Fiona release the crs attribute of features will


    ~/.conda/envs/kris/lib/python3.7/site-packages/fiona/env.py in wrapper(*args, **kwargs)
        394     def wrapper(*args, **kwargs):
        395         if local._env:
    --> 396             return f(*args, **kwargs)
        397         else:
        398             if isinstance(args[0], str):


    ~/.conda/envs/kris/lib/python3.7/site-packages/fiona/__init__.py in open(fp, mode, driver, schema, crs, encoding, layer, vfs, enabled_drivers, crs_wkt, **kwargs)
        251         if mode in ('a', 'r'):
        252             c = Collection(path, mode, driver=driver, encoding=encoding,
    --> 253                            layer=layer, enabled_drivers=enabled_drivers, **kwargs)
        254         elif mode == 'w':
        255             if schema:


    ~/.conda/envs/kris/lib/python3.7/site-packages/fiona/collection.py in __init__(self, path, mode, driver, schema, crs, encoding, layer, vsi, archive, enabled_drivers, crs_wkt, ignore_fields, ignore_geometry, **kwargs)
        157             if self.mode == 'r':
        158                 self.session = Session()
    --> 159                 self.session.start(self, **kwargs)
        160             elif self.mode in ('a', 'w'):
        161                 self.session = WritingSession()


    fiona/ogrext.pyx in fiona.ogrext.Session.start()


    fiona/_shim.pyx in fiona._shim.gdal_open_vector()


    DriverError: Overvægtige/DATA/countries_110m/ne_110m_admin_0_countries.shp: No such file or directory



```python
cw_year['country'].value_counts()
```




    Afghanistan                 3722
    Mexico                       646
    Nigeria                      520
    Somalia                      486
    India                        475
    DR Congo (Zaire)             401
    Yemen (North Yemen)          333
    Iraq                         254
    Cameroon                     233
    Mali                         215
    Turkey                       163
    Ukraine                      151
    South Sudan                  147
    Philippines                  123
    Libya                        123
    Sudan                         90
    Brazil                        87
    Egypt                         82
    Central African Republic      77
    Pakistan                      77
    Kenya                         64
    Colombia                      57
    Ethiopia                      56
    Mozambique                    44
    Burkina Faso                  42
    Myanmar (Burma)               41
    Thailand                      40
    Burundi                       38
    Israel                        33
    Niger                         24
    Russia (Soviet Union)         21
    Bangladesh                    18
    Azerbaijan                    17
    Iran                          12
    Nicaragua                     12
    Chad                          12
    Algeria                       10
    Saudi Arabia                   8
    France                         8
    Indonesia                      7
    Angola                         6
    Tunisia                        6
    Rwanda                         3
    Zimbabwe (Rhodesia)            2
    Belgium                        2
    Guinea                         2
    Australia                      2
    Uganda                         2
    Senegal                        1
    Djibouti                       1
    Tanzania                       1
    Congo                          1
    Tajikistan                     1
    Armenia                        1
    Lebanon                        1
    Haiti                          1
    Name: country, dtype: int64




```python
# Grouping by 'Date' I can make a timeline plotting number of outbreaks pr. day:
grouped = cw_year.groupby('country')

cw_year_count = grouped.count()
cw_year_grouped = grouped.sum()

cw_year_grouped['Armed conflicts'] = cw_year_count['best']
cw_year_grouped.reset_index(inplace=True)

# Remove Afghanistan from the list
cw_year_grouped = cw_year_grouped[cw_year_grouped['country'] != 'Afghanistan']
cw_year_grouped.reset_index(inplace=True)

print('Countries:', len(cw_year_grouped))
cw_year_grouped.head(5)
```

    Countries: 55





<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>index</th>
      <th>country</th>
      <th>year</th>
      <th>latitude</th>
      <th>longitude</th>
      <th>best</th>
      <th>Africa</th>
      <th>Americas</th>
      <th>Asia</th>
      <th>Europe</th>
      <th>Middle East</th>
      <th>Armed conflicts</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>Algeria</td>
      <td>20180</td>
      <td>348.247775</td>
      <td>45.884229</td>
      <td>35</td>
      <td>10.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>10</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>Angola</td>
      <td>12108</td>
      <td>-47.908549</td>
      <td>101.475650</td>
      <td>24</td>
      <td>6.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>6</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>Armenia</td>
      <td>2018</td>
      <td>40.854687</td>
      <td>45.577810</td>
      <td>1</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>Australia</td>
      <td>4036</td>
      <td>-75.627222</td>
      <td>289.926112</td>
      <td>2</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>2</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>Azerbaijan</td>
      <td>34306</td>
      <td>680.044400</td>
      <td>795.137964</td>
      <td>16</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>17.0</td>
      <td>0.0</td>
      <td>17</td>
    </tr>
  </tbody>
</table>
</div>




```python
fig, ax = plt.subplots(figsize = (15,6))
fig = cw_year_grouped.plot(x="country", y=["Africa" , "Asia", "Europe", "Middle East", "Americas"], kind="bar", color=['lightpink', 'lightblue', 'red' , 'lightyellow', 'lightgreen'], width=2, ax=ax)

x = cw_year_grouped['country']

plt.title('Armed conflicts in 2018')
plt.ylabel('Armed conflicts')
plt.xlabel('Country')

plt.show()
```


![png](output_7_0.png)



```python
# join the geodataframe with the csv dataframe
merged = gdf.merge(cw_year_grouped, how='right', left_on="country", right_on="country")
merged = merged[['country', 'geometry', 'best' ]]

merged.head()

```


    ---------------------------------------------------------------------------

    NameError                                 Traceback (most recent call last)

    <ipython-input-14-282835ed56e4> in <module>
          1 # join the geodataframe with the csv dataframe
    ----> 2 merged = gdf.merge(cw_year_grouped, how='right', left_on="country", right_on="country")
          3 merged = merged[['country', 'geometry', 'best' ]]
          4 
          5 merged.head()


    NameError: name 'gdf' is not defined



```python
import json

#Read data to json
merged_json = json.loads(merged.to_json())

#Convert to str like object
json_data = json.dumps(merged_json)

```


```python
import matplotlib.pyplot as plt
from mpl_toolkits.axes_grid1 import make_axes_locatable

fig, ax = plt.subplots(1, 1)
divider = make_axes_locatable(ax)


from matplotlib.pyplot import figure
figure(num=None, figsize=(15, 10), dpi=80, facecolor='w', edgecolor='k')
cax = divider.append_axes("right", size="5%", pad=0.05)
    
merged.plot(column=merged['best'], ax=ax, cax = cax, legend = True, cmap='OrRd',figsize=(15, 10));


```


![png](output_10_0.png)



    <Figure size 1200x800 with 0 Axes>



```python
from bokeh.io import output_notebook, show, output_file
from bokeh.plotting import figure
from bokeh.models import GeoJSONDataSource, LinearColorMapper, ColorBar
from bokeh.palettes import brewer
#Input GeoJSON source that contains features for plotting.
geosource = GeoJSONDataSource(geojson = json_data)
#Define a sequential multi-hue color palette.
palette = brewer['YlGnBu'][8]
#Reverse color order so that dark blue is highest obesity.
palette = palette[::-1]
#Instantiate LinearColorMapper that linearly maps numbers in a range, into a sequence of colors.
color_mapper = LinearColorMapper(palette = palette, low = 0, high = 40000)
#Define custom tick labels for color bar.
tick_labels = {'0': '0', '50': '50', '100':'100', '500':'500', '1000':'1000', '2000':'2000', '3000':'3000'}
#Create color bar. 
color_bar = ColorBar(color_mapper=color_mapper, label_standoff=8,width = 500, height = 20,
border_line_color=None,location = (0,0), orientation = 'horizontal', major_label_overrides = tick_labels)
#Create figure object.
p = figure(title = 'Share of adults who are obese, 2016', plot_height = 600 , plot_width = 950, toolbar_location = None)
p.xgrid.grid_line_color = None
p.ygrid.grid_line_color = None
#Add patch renderer to figure. 
p.patches('xs','ys', source = geosource,fill_color = {'field' :'best', 'transform' : color_mapper},
          line_color = 'black', line_width = 0.25, fill_alpha = 1)
#Specify figure layout.
p.add_layout(color_bar, 'below')
#Display figure inline in Jupyter Notebook.
output_notebook()
#Display figure.
show(p)

```



<div class="bk-root">
    <a href="https://bokeh.pydata.org" target="_blank" class="bk-logo bk-logo-small bk-logo-notebook"></a>
    <span id="1156">Loading BokehJS ...</span>
</div>











<div class="bk-root" id="6ec61a6e-1f4a-4a74-88d6-cb1019b42ed8" data-root-id="1117"></div>






```python

```
